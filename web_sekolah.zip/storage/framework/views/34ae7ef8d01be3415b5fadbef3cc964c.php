<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SMKS PGRI WLINGI</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary shadow-sm">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center fw-bold" href="#">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR76PRx-4AzIHeiR8nvuGRE5IzJnuD3HRGydNF694A19Q&s=10"
                    alt="Logo" width="30" height="30" class="d-inline-block me-2">
                SMKS PGRI WLINGI
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active fw-bold text-primary" href="#">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Akademik</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Kesiswaan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Berita</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Galeri</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Kontak</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- CAROUSEL SLIDER -->
    <div id="carouselExampleCaptions" class="carousel slide">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://smkpgriwlingi.sch.id/gambar/hero-sekolah.jpeg" class="d-block w-100" height="450"
                    alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Some representative placeholder content for the first slide.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://smkpgriwlingi.sch.id/gambar/keahlian/1789699283_hero.jpg" class="d-block w-100"
                    height="450" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Second slide label</h5>
                    <p>Some representative placeholder content for the second slide.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="https://smkpgriwlingi.sch.id/gambar/dropzone/IMG_8778_1784596927.jpg" class="d-block w-100"
                    height="450" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Third slide label</h5>
                    <p>Some representative placeholder content for the third slide.</p>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>

    <!-- KONTEN SAMBUTAN -->
    <div class="container">
        <div class="row align-items-start">
            <div class="col-9">
                <div class="card mt-3 mb-5">
                    <div class="card-body">
                        <h3>sambutan kepala sekolah</h3>
                        <div class="row">
                            <div class="col-md-3">
                                <img src="https://sikabar.smkpgriwlingi.sch.id/img/guru-putih/Drs.%20BAMBANG%20SETIYONO,%20ST,%20M.Pd.jpg"
                                    class="img-thumbnail" alt="...">
                            </div>
                            <div class="col-md-9">
                                <h4>Assalamu’alaikum Warahmatullahi Wabarakatuh</h4>
                                Selamat pagi/siang, dan salam sejahtera bagi
                                kita semua.Puji syukur marilah kita panjatkan ke hadirat Allah SWT, karena atas rahmat,
                                berkah, dan karunia-Nya kita semua dapat berkumpul di tempat ini dalam keadaan sehat
                                walafiat. Salawat serta salam semoga senantiasa tercurah kepada junjungan kita, Nabi
                                Muhammad SAW.Pada kesempatan yang berbahagia ini, saya ingin menyampaikan terima kasih
                                yang sebesar-besarnya kepada seluruh bapak/ibu guru, staf tata usaha, orang tua murid,
                                serta seluruh panitia yang telah bekerja keras dan bekerja sama dengan luar biasa
                                sehingga acara ini dapat terselenggara dengan baik.Perlu kami sampaikan bahwa sekolah
                                kita akan terus berkomitmen untuk meningkatkan mutu pendidikan, baik dari segi akademik
                                maupun dalam pembentukan karakter serta akhlak mulia para siswa. Tentu saja, komitmen
                                ini tidak akan berjalan maksimal tanpa adanya sinergi yang kuat. Oleh karena itu, kami
                                sangat mengharapkan dukungan penuh dari para orang tua dan seluruh lapisan masyarakat
                                agar terus terjalin kerja sama yang baik demi kemajuan anak-anak kita tercinta.Secara
                                khusus kepada seluruh siswa-siswi sekalian, pesan saya: tetaplah rajin belajar, selalu
                                jaga kedisiplinan, hormati guru dan orang tua, serta raihlah cita-cita kalian setinggi
                                mungkin.Terakhir, saya selaku kepala sekolah memohon maaf yang sebesar-besarnya apabila
                                dalam penyambutan maupun pelaksanaan acara ini terdapat kekurangan dan hal-hal yang
                                kurang berkenan. Terima kasih atas perhatian dan kehadiran semuanya.
                                <h4>Wassalamu’alaikum Warahmatullahi Wabarakatuh.</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h5 class="fw-bold m-0">Kegiatan Terbaru</h5>
                    <a href="#" class="text-decoration-none small text-muted">Lihat Semua Kegiatan</a>
                </div>
                <div class="card mt-3">
                    <div class="card">
                        <div class="card-body">
                            <p><a class="link-opacity-80" href="https://www.ox.ac.uk/">University Of Oxford</a>
                            </p>
                            <p><a class="link-opacity-80" href="https://www.oed.com/?tl=true">Oxford Leaners
                                    Dictonary's</a>
                            </p>
                            <p><a
                                    class="link-opacity-80"href="https://www.ox.ac.uk/admissions/graduate/courses/find-your-course">Postgraduate
                                    Oxford</a>
                            </p>
                            <p><a class="link-opacity-80"href="https://youtu.be/lLC75gPigTQ?si=Yu-3I9_hBfOpii8A">Oxford
                                    from the air</a>
                            </p>
                            <p><a class="link-opacity-80"href="https://youtu.be/QQi0js8IXmg?si=tA-sIv6yUACsxgBN">Vibe
                                    in Oxford</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row align-items-start">
            <div class="card" style="width: 18rem;">
                <img src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Oxford_University_Press_Building_%E2%80%93_Walton_Street.jpg?utm_source=id.wikipedia.org&utm_campaign=index&utm_content=original"
                    class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Oxford adalah Universitas terkenal yg masuk dalam 5 besar universitas
                        bergengsi didunia. <br>
                        <a class="link-opacity-80"href="https://id.wikipedia.org/wiki/Oxford_University_Press">Penjelasan
                            terkait Oxford</a>
                    </p>
                </div>
            </div>
            <div class="card" style="width: 18rem;">
                <img src="https://www.experienceoxfordshire.org/wp-content/uploads/2017/03/Experience-Oxfordshire-Oxford-compressed37-scaled.jpg"
                    class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Bahkan berdirinya Oxford lebih lama, bahkan sebelum kerajaan-kerajaan inggris
                        dibangun. <br>
                        <a
                            class="link-opacity-80"href="https://www.experienceoxfordshire.org/wp-content/uploads/2017/03/Experience-Oxfordshire-Oxford-compressed37-scaled.jpg">
                            Experience Oxfordshire</a>
                    </p>
                    </p>
                </div>
            </div>
            <div class="card" style="width: 18rem;">
                <img src="https://images.squarespace-cdn.com/content/v1/6161bb5d58ee4e21599a0ec6/d9483760-c7e8-4029-aded-065d6ec174a0/_DSC6634_1199x800.jpg"
                    class="card-img-top" alt="...">
                <div class="card-body">
                    <p class="card-text">Oxford juga termasuk destinasi wisata dengan vibe yg aesthetic, indah dan
                        bertemakan fantasi. <br>
                        <a class="link-opacity-80"href="https://www.walkmeblog.com/posts/oxford-walking-tour">See in
                            Oxford</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    <nav class="navbar fixed-bottom bg-body-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">web personal &copy;</a>
            <a class="navbar-brand" href="#">dikembangkan oleh : Rika wahyu & Cindy aulia</a>
        </div>
    </nav>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<?php /**PATH C:\laragon\www\web_sekolah\resources\views\beranda.blade.php ENDPATH**/ ?>